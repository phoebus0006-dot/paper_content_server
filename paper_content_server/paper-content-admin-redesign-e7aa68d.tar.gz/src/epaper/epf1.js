// epf1.js — EPF1 frame encoding
// Mirrors FRAME_HEADER_BYTES, FRAME_PAYLOAD_BYTES, buildFrameBuffer from server.js.
// Do NOT change magic, dimensions, panel, version, nibble packing, or constants.

var palette = require('./palette');

var EPF1_CONSTANTS = {
  MAGIC: 'EPF1',
  WIDTH: 800,
  HEIGHT: 480,
  PANEL: 49,
  VERSION: 1,
  HEADER_BYTES: 10,
  get PAYLOAD_BYTES() { return Math.ceil((this.WIDTH * this.HEIGHT) / 2); },
  get TOTAL_BYTES() { return this.HEADER_BYTES + this.PAYLOAD_BYTES; },
};

function packPixels(leftCode, rightCode) {
  palette.assertAllowedCode(leftCode);
  palette.assertAllowedCode(rightCode);
  return ((leftCode & 0x0F) << 4) | (rightCode & 0x0F);
}

function buildHeader() {
  var header = Buffer.alloc(EPF1_CONSTANTS.HEADER_BYTES);
  header.write(EPF1_CONSTANTS.MAGIC, 0, 4, 'ascii');
  header.writeUInt16LE(EPF1_CONSTANTS.WIDTH, 4);
  header.writeUInt16LE(EPF1_CONSTANTS.HEIGHT, 6);
  header.writeUInt8(EPF1_CONSTANTS.PANEL, 8);
  header.writeUInt8(EPF1_CONSTANTS.VERSION, 9);
  return header;
}

function encodePayload(codes) {
  var totalPixels = EPF1_CONSTANTS.WIDTH * EPF1_CONSTANTS.HEIGHT;
  if (codes.length !== totalPixels) {
    throw new Error('Expected ' + totalPixels + ' codes, got ' + codes.length);
  }
  var payload = Buffer.alloc(EPF1_CONSTANTS.PAYLOAD_BYTES, 0x11);
  for (var i = 0; i < codes.length; i += 2) {
    var left = codes[i];
    var right = (i + 1 < codes.length) ? codes[i + 1] : 1;
    palette.assertAllowedCode(left);
    palette.assertAllowedCode(right);
    payload[i / 2] = packPixels(left, right);
  }
  return payload;
}

function encodeFrame(codes) {
  var payload = encodePayload(codes);
  var header = buildHeader();
  return Buffer.concat([header, payload]);
}

function hexPreview(buf, bytes) {
  bytes = bytes || 32;
  var parts = [];
  for (var i = 0; i < bytes && i < buf.length; i++) {
    parts.push(buf[i].toString(16).padStart(2, '0'));
  }
  return parts.join(' ');
}

module.exports = {
  EPF1_CONSTANTS: EPF1_CONSTANTS,
  packPixels: packPixels,
  buildHeader: buildHeader,
  encodePayload: encodePayload,
  encodeFrame: encodeFrame,
  hexPreview: hexPreview,
};
