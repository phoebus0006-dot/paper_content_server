#!/usr/bin/env node
var path=require('path');var cp=require('child_process');var ROOT=path.join(__dirname,'..','..');
var tests=['test/r12/mqtt-frame-sha256-test.js'];
var overall=false;tests.forEach(function(f){var p=path.join(ROOT,f);console.log('\n=== Running '+f+' ===');var r=cp.spawnSync(process.execPath,[p],{cwd:ROOT,stdio:'inherit',timeout:30000});if(r.status!==0){console.log('FAIL: '+f);overall=true;}});
if(overall){console.log('\n=== R12: some tests FAILED ===');process.exit(1);}else{console.log('\n=== R12: ALL TESTS PASSED ===');process.exit(0);}
